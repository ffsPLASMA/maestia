from Sanae3D import Engine

engine = Engine.SanaeEngine()
engine.run()