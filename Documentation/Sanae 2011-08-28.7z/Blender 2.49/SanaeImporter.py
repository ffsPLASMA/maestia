#!BPY
 
"""
Name: '.Sanae Importer'
Blender: 249
Group: 'Import'
Tooltip: 'Use Sanae 3D to import a model'
"""

import Blender, os, sys
from Sanae3D import Engine
import Sanae3D.lib.BlenderImport as B


def load_file(path):
    
    reload(Engine)
    
    engine = Engine.SanaeEngine()
    obj = engine.run_blender(path)
    print "parsed", obj
    dirPath = os.path.dirname(path)

    reload(B)
    drawer = B.BlenderImport(obj, dirPath)
    print "ready to draw"
    drawer.draw_mesh()

Blender.Window.FileSelector(load_file, 'Import')