#Struct writer
import struct

#big endian = 1
#little endian = 0

class StructWriter(object):
    
    def __init__(self, openFile):
        
        self.outFile = openFile
    
    def close(self):
        
        self.outFile.close()
        
    def write(self, output):
        
        self.outFile.write(output)
        
    def tell(self):
        
        return self.outFile.tell()
        
    def seek(self, n, mode=0):
        '''Seek to offset n using the specified mode.
           0 = seek set
           1 = seek cur'''
        
        self.outFile.seek(n, mode)
        
    #basic packing functions. Does not allow any options.
    #Alternative is to use the pack method to specify your arguments

    def write_string(self, string, n=0):
        
        if n:
            string = string.ljust(n, "\x00")
        self.outFile.write(string)
            
    def write_null(self, n):
        '''write n 00's to the file'''
        
        self.outFile.write("\x00" * n)
        
    def write_float(self, *args):
        
        self.outFile.write(struct.pack("%df" %len(args), *args))
        
    def write_long(self, *args):
        
        self.outFile.write(struct.pack("%dl" %len(args), *args))
        
    def write_ulong(self, *args):
        
        self.outFile.write(struct.pack("%dL" %len(args), *args))
        
    def write_short(self, *args):
        
        self.outFile.write(struct.pack("%dh" %len(args), *args))
        
    def write_ushort(self, *args):
        
        self.outFile.write(struct.pack("%dH" %len(args), *args))
        
    def write_byte(self, *args):
        '''write out a signed byte'''
        
        self.outFile.write(struct.pack("%db" %len(args), *args))
        
    def write_ubyte(self, *args):
        '''write out unsigned byte'''
        
        self.outFile.write(struct.pack("%dB" %len(args), *args))
        
    def pack(self, fmt, *args):
        
        self.outFile.write(struct.pack(fmt, *args))