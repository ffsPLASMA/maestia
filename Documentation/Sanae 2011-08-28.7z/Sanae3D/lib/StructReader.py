#a struct reader

import struct

UNSIGNED = 0

#big endian = 1
#little endian = 0

class StructReader(object):
    
    def __init__(self, openFile):
        
        self.inFile = openFile
        
    def filesize(self, offset=0):
        
        self.inFile.seek(0, 2)
        size = self.inFile.tell()
        self.inFile.seek(offset)
        return size
        
    def close(self):
        
        self.inFile.close()
        
    def read(self, n=0):
        ''' '''
        
        if not n:
            return self.inFile.read()
        return self.inFile.read(n)
    
    def readline(self):
        
        return self.inFile.readline()
    
    def skip_lines(self, string):
        
        line = self.inFile.readline()
        while not line.strip().startswith(string):
            line = self.inFile.readline()
        return line
    
    def seek(self, n, mode=0):
        
        self.inFile.seek(n, mode)
        
    def tell(self):
        
        return self.inFile.tell()
    
    #Binary-related methods
    
    def read_string(self, n, delim=""):
        '''return a string of n characters'''
        
        string = struct.unpack('%ds' %n, self.inFile.read(n))[0]
        if delim:
            string = string.split(delim)[0]
        return string
    
    def read_float(self, n=1, end=0):
        '''Read n floats from inFile'''
        
        if end:
            fmt = ">%df" %n
        else:
            fmt = "%df" %n
        data = struct.unpack(fmt, self.inFile.read(n*4))
        if n == 1:
            return data[0]
        return data
        
    def read_long(self, n=1, end=0):
        ''' read n longs from inFile'''
        
        if end:
            fmt = ">%dl" %n
        else:
            fmt = "%dl" %n
        data = struct.unpack(fmt, self.inFile.read(n*4))
        if n == 1:
            return data[0]
        return data
    
    def read_ulong(self, n=1, end=0):
        
        if end:
            fmt = ">%dL" %n
        else:
            fmt = "%dL" %n
            
        data = struct.unpack(fmt, self.inFile.read(n*4))
        if n == 1:
            return data[0]
        return data
    
    def read_short(self, n=1, end=0):
        '''reads n shorts from inFile'''
        
        if end:
            fmt = ">%dh" %n
        else:
            fmt = "%dh" %n
        data = struct.unpack(fmt, self.inFile.read(n*2))
        if n == 1:
            return data[0]
        return data
    
    def read_ushort(self, n=1, end=0):
        
        if end:
            fmt = ">%dH" %n
        else:
            fmt = "%dH" %n
        data = struct.unpack(fmt, self.inFile.read(n*2))
        if n == 1:
            return data[0]
        return data
    
    def read_char(self, n=1):
        '''Read n chars from inFile'''
        
        data = struct.unpack('%dc' %n, self.inFile.read(n))
        if n == 1:
            return data[0]
        return data
    
    def read_byte(self, n=1):
        
        data = struct.unpack('%db' %n, self.inFile.read(n))           
        if n == 1:
            return data[0]
        return data
        
    def read_ubyte(self, n=1):
        
        data = struct.unpack('%dB' %n, self.inFile.read(n))
        if n == 1:
            return data[0]
        return data