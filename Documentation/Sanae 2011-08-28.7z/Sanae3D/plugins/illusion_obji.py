#Illusion OBJF format parser

from _illusion_obj import Illusion_OBJ
from Sanae3D.lib.StructReader import StructReader

#Brutish mine objf is different from biko 2 objf.
#Can use mesh name to check since BM mesh names use abspath

class Illusion_OBJF(Illusion_OBJ):
    
    def __init__(self, obj3D=None, outFile=None, inFile=None):
        
        super(Illusion_OBJF,self).__init__("OBJF")
        self.obj3D = obj3D
        self.inFile = inFile
        self.outFile = outFile
        
    def parse_vertices(self, meshName, numVerts):
        
        for i in range(numVerts):
            vx, vy, vz = self.inFile.read_float(3)            
            nx, ny, nz = self.inFile.read_float(3)
            tu, tv = self.inFile.read_float(2)
            vx = float(vx) * -1.0
            
            self.create_vertex(meshName, i)
            self.add_coords(meshName, i, [vx, vy, vz])
            self.add_vert_uv(meshName, i, [tu, tv])
            self.add_vert_normals(meshName, i, [nx, ny, nz])
            
    def parse_biko2_submesh(self, meshName):
        
        self.create_object(meshName)
        self.inFile.read_long()
        matID, texID = self.inFile.read_long(2)
        self.inFile.seek(4, 1)    #null
        numVerts = self.inFile.read_long()
        numFaces = self.inFile.read_long() / 3
        matNum = self.tempMats[matID]
        self.add_texture_name(matNum, self.tempTex[texID])
        
        self.parse_vertices(meshName, numVerts)
        self.parse_faces(meshName, numFaces, matNum)
        
    def parse_BM_submesh(self, meshName, numMesh):
        '''Brutish mine objf format is different'''
        
        meshName = ''.join([meshName, "[%d]" %numMesh])
        self.create_object(meshName)

        unk, matID, texID, numVerts = self.inFile.read_long(4)
        numFaces = self.inFile.read_long() / 3
        
        matNum = self.tempMats[matID]
        self.add_texture_name(matNum, self.tempTex[texID])
        
        self.parse_vertices(meshName, numVerts)
        self.parse_faces(meshName, numFaces, matNum)
    
    def parse_meshes(self, sectLen):
        
        sectEnd = self.inFile.tell() + sectLen
        while self.inFile.tell() != sectEnd:
            meshName = self.read_name(64)
            meshID, numMesh = self.inFile.read_long(2)
            if meshName.startswith("C:"):
                name = meshName.split('.')[1]
                for i in range(numMesh):
                    self.parse_BM_submesh(name, i)
            else:
                if numMesh == 1:
                    self.parse_biko2_submesh(meshName)
                else:
                    for i in range(numMesh):
                        meshName = self.read_name(64)
                        meshID, numMesh = self.inFile.read_long(2)
                        self.parse_biko2_submesh(meshName)
    
    def parse_frames(self, sectLen):
        
        numFrames = sectLen / 252
        
        for i in range(numFrames):
            frameName = self.read_name(64)
            frameID = self.inFile.read_long()
            
            frameMatrix = self.inFile.read_float(16)
            self.inFile.seek(40, 1)
            parentID = self.inFile.read_long()
            self.inFile.seek(76, 1)
            
            self.create_frame(frameID)
            self.add_frame_name(frameID, frameName)
            self.add_parent_frame(frameID, parentID)
            parentID = self.get_frame_parent(frameID)
            
         
def read_file(path):
    '''Read the file'''
    
    openFile = StructReader(open(path, 'rb'))
    obj = Illusion_OBJF(inFile=openFile)
    obj.parse_file()
    openFile.close()
    return obj

def write_file(path):
    
    pass

def definitions():
    '''Return the header, extension, and a description of the format'''
    
    return "OBJI", "X", "Illusion OBJI"

if __name__ == '__main__':
    
    file1 = "i005_00.x"
    file2 = "a080_00_00.x"
    file3 = "i020_00_00.x"
    file4 = "q002_00_00.x"
    file5 = "b002_00.x"
    obj = read_file(file5)