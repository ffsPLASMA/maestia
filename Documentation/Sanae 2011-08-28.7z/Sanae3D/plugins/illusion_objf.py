#Illusion OBJF format parser

from _illusion_obj import Illusion_OBJ
from Sanae3D.lib.StructReader import StructReader

#Brutish mine objf is different from biko 2 objf.
#Can use mesh name to check since BM mesh names use abspath

class Illusion_OBJF(Illusion_OBJ):
    
    def __init__(self, obj3D=None, outFile=None, inFile=None):
        
        super(Illusion_OBJF,self).__init__("OBJF")
        self.obj3D = obj3D
        self.inFile = inFile
        self.outFile = outFile
        
    def parse_vertices(self, meshName, numVerts):
        
        for i in range(numVerts):
            vx, vy, vz = self.inFile.read_float(3)            
            nx, ny, nz = self.inFile.read_float(3)
            tu, tv = self.inFile.read_float(2)
            vx = float(vx) * -1.0
            
            self.create_vertex(meshName, i)
            self.add_coords(meshName, i, [vx, vy, vz])
            self.add_vert_uv(meshName, i, [tu, tv])
            self.add_vert_normals(meshName, i, [nx, ny, nz])
            
    def parse_biko2_submesh(self, meshName):
        
        self.create_object(meshName)
        self.inFile.read_long()
        matID, texID = self.inFile.read_long(2)
        self.inFile.seek(4, 1)    #null
        numVerts = self.inFile.read_long()
        numFaces = self.inFile.read_long() / 3
        matNum = self.tempMats[matID]
        self.add_texture_name(matNum, self.tempTex[texID])
        
        self.parse_vertices(meshName, numVerts)
        self.parse_faces(meshName, numFaces, matNum)
        return meshName
        
    def parse_BM_submesh(self, meshName, numMesh):
        '''Brutish mine objf format is different'''
        
        meshName = ''.join([meshName, "[%d]" %numMesh])
        self.create_object(meshName)

        unk, matID, texID, numVerts = self.inFile.read_long(4)
        numFaces = self.inFile.read_long() / 3
        
        matNum = self.tempMats[matID]
        self.add_texture_name(matNum, self.tempTex[texID])
        
        self.parse_vertices(meshName, numVerts)
        self.parse_faces(meshName, numFaces, matNum)
        
    
    def parse_meshes(self, sectLen):
        
        sectEnd = self.inFile.tell() + sectLen
        while self.inFile.tell() != sectEnd:
            meshName = self.read_name(64)
            meshID, numMesh = self.inFile.read_long(2)
            self.meshIDs[meshID] = meshName
            if meshName.startswith("C:"):
                name = meshName.split('.')[1]
                for i in range(numMesh):
                    self.parse_BM_submesh(name, i)
            else:
                if numMesh == 1:
                    #no submesh
                    self.parse_biko2_submesh(meshName)
                else:
                    #ignore main mesh and create submeshes
                    self.submeshes[meshName] = []
                    for i in range(numMesh):
                        
                        subMeshName = self.read_name(64)
                        self.submeshes[meshName].append(subMeshName)
                        
                        meshID, numMesh = self.inFile.read_long(2)
                        self.parse_biko2_submesh(subMeshName)
                    #print meshName, self.submeshes[meshName]
    
    def parse_frames(self, sectLen):
        
        numFrames = sectLen / 156
        
        for i in range(numFrames):
            frameName = self.read_name(64)
            frameID = self.inFile.read_long()
            frameMatrix = self.inFile.read_float(16)
            null, parentID, meshID = self.inFile.read_long(3)
            self.inFile.read_long(3)
            
            self.create_frame(frameID)
            self.add_frame_name(frameID, frameName)
            self.add_frame_transform(frameID, frameMatrix)
            if meshID:
                meshName = self.meshIDs[meshID]
                self.add_frame_mesh(frameID, meshName)
                if meshName in self.get_objects():
                    self.add_mesh_transform(meshName, frameMatrix)
                else:
                    if self.submeshes.has_key(meshName):
                        for submesh in self.submeshes[meshName]:
                            self.add_mesh_transform(submesh, frameMatrix)
         
def read_file(path):
    '''Read the file'''
    
    openFile = StructReader(open(path, 'rb'))
    obj = Illusion_OBJF(inFile=openFile)
    obj.parse_file()
    openFile.close()
    return obj

def write_file(path):
    
    pass

def definitions():
    '''Return the header, extension, and a description of the format'''
    
    return "OBJF", "X", "Illusion OBJF"

if __name__ == '__main__':
    
    file1 = "can.x"
    file2 = "m006_00.x"
    obj = read_file(file2)