#Illusion OBJM format parser

from _illusion_obj import Illusion_OBJ
from Sanae3D.lib.StructReader import StructReader

class Illusion_OBJM(Illusion_OBJ):
    
    def __init__(self, obj3D=None, outFile=None, inFile=None):
        
        super(Illusion_OBJM,self).__init__("OBJM")
        self.obj3D = obj3D
        self.inFile = inFile
        self.outFile = outFile
        
    def parse_vertices(self, meshName, numVerts):
        
        for i in range(numVerts):
            
            vx, vy, vz = self.inFile.read_float(3)
            self.inFile.read_float(1)
            nx, ny, nz = self.inFile.read_float(3)
            tu, tv = self.inFile.read_float(2)
            self.inFile.seek(24, 1)   #nulls
            
            vx = float(vx) * -1.0
            
            self.create_vertex(meshName, i)
            self.add_coords(meshName, i, [vx, vy, vz])
            self.add_vert_uv(meshName, i, [tu, tv])
            self.add_vert_normals(meshName, i, [nx, ny, nz])
            
    def parse_submesh(self, meshName):
        
        self.create_object(meshName)
        
        self.inFile.read_long()    #null
        matID, texID = self.inFile.read_long(2)
        self.inFile.seek(12, 1)    #null
        self.inFile.read_long()
        self.inFile.seek(12, 1)    #null
        self.inFile.read_long()
        self.inFile.seek(20, 1)    #null
        numVerts = self.inFile.read_long()
        numFaces = self.inFile.read_long() / 3
        self.inFile.read_long()
        self.inFile.seek(256, 1)    #null
        
        matNum = self.tempMats[matID]
        if texID:
            self.add_texture_name(matNum, self.tempTex[texID])
        
        self.parse_vertices(meshName, numVerts)
        self.parse_faces(meshName, numFaces, matNum)
    
    def parse_meshes(self, sectLen):
        
        sectEnd = self.inFile.tell() + sectLen
        while self.inFile.tell() != sectEnd:
            name = self.read_name(64)
            meshID, numMesh = self.inFile.read_long(2)
            if numMesh == 1:
                self.parse_submesh(name)
            else:
                for i in range(numMesh):
                    meshName = self.read_name(64)
                    meshID, matNum = self.inFile.read_long(2)
                    self.parse_submesh(meshName)
    
    def parse_frames(self, sectLen):
        
        numFrames = sectLen / 396
        
        for i in range(numFrames):
            frameName = self.read_name(64)
            frameID = self.inFile.read_long()
            frameMatrix = self.inFile.read_float(16)
            self.inFile.seek(40, 1)    #nulls
            parentID = self.inFile.read_long()
            self.inFile.seek(220, 1)   #nulls
         
def read_file(path):
    '''Read the file'''
    
    openFile = StructReader(open(path, 'rb'))
    obj = Illusion_OBJM(inFile=openFile)
    obj.parse_file()
    openFile.close()
    return obj

def write_file(path):
    
    pass

def definitions():
    '''Return the header, extension, and a description of the format'''
    
    return "OBJM", "X", "Illusion OBJM"

if __name__ == '__main__':
    
    file1 = "can.x"
    file2 = "m006_00.x"
    file3 = "d0001_00_00.x"
    obj = read_file(file3)