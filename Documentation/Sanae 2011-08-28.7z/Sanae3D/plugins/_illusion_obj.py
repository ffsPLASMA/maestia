#Generic Illusion OBJ% parser

import os, sys
from Sanae3D.lib.ModelObject import Model3D
from Sanae3D.lib.StructReader import StructReader

class Illusion_OBJ(Model3D):
    '''Generic Illusion OBJ parser. Provides common methods that are shared
    between various OBJ% formats. All illusion OBJ% classes will inherit from
    this class'''
    
    MAT_SIZE = 140
    TEX_SIZE = 204
    
    def __init__(self, obj3D=None, outFile=None, inFile=None):
        
        super(Illusion_OBJ,self).__init__("obj3D")
        self.obj3D = obj3D
        self.inFile = inFile
        self.outFile = outFile
        self.tempMats = {}
        self.tempTex = {}
        self.meshIDs = {}
        self.submeshes = {} #{meshID : 
        
    def read_name(self, n):
        
        return self.inFile.read_string(n).split("\x00")[0]
        
    def parse_materials(self, sectLen):
        
        numMat = sectLen / self.MAT_SIZE
        for i in range(numMat):
            matName = self.read_name(64)
            matID = self.inFile.read_long()
            unk = self.inFile.read_float(8)
            self.inFile.seek(16, 1)
            unk2 = self.inFile.read_float(6)
            
            self.tempMats[matID] = i
            self.create_material(i)
            self.add_material_name(i, matName)
    
    def parse_textures(self, sectLen):
        
        numTex = sectLen / self.TEX_SIZE
        for i in range(numTex):
            texName = self.read_name(64)
            texID = self.inFile.read_long()
            texFile = self.read_name(136)            
            
            self.tempTex[texID] = texName
            
    def parse_faces(self, meshName, numFaces, matNum):
        
        for i in range(numFaces):
            v1, v2, v3 = self.inFile.read_short(3)
            
            self.create_face(meshName, i)
            self.add_face_verts(meshName, i, [v1, v2, v3])
            self.add_face_material(meshName, i, matNum)
        
    def parse_vertices(self, meshName, numVerts):
        
        for i in range(numVerts):
            vx, vy, vz = self.inFile.read_float(3)
            nx, ny, nz = self.inFile.read_float(3)
            tu, tv = self.inFile.read_float(2)
            
            self.create_vertex(meshName, i)
            self.add_coords(meshName, i, [vx, vy, vz])
            
    def parse_submesh(self, meshName):
        
        self.create_object(meshName)
        
        self.inFile.read_long()
        self.inFile.read_float(2)
        self.inFile.seek(4, 1)    #null
        numVerts = self.inFile.read_long()
        numFaces = self.inFile.read_long() / 3
        
        self.parse_vertices(meshName, numVerts)
        self.parse_faces(meshName, numFaces)
    
    def parse_meshes(self, sectLen):
        
        sectEnd = self.inFile.tell() + sectLen
        while self.inFile.tell() != sectEnd:
            name = self.read_name(64)
            meshID, numMesh = self.inFile.read_long(2)
            if numMesh == 1:
                self.parse_submesh(name)
            else:
                for i in range(numMesh):
                    meshName = self.read_name(64)
                    meshID, numMesh = self.inFile.read_long(2)
                    self.parse_submesh(meshName)
    
    def parse_frames(self, sectLen):
        
        numFrames = sectLen / 156
        
        for i in range(numFrames):
            frameName = self.read_name(64)
            frameID = self.inFile.read_long()
            frameMatrix = self.inFile.read_float(16)
            unkID, parentID = self.inFile.read_long(2)
            self.inFile.read_long(4)
        
    def parse_file(self):
        '''Main parser method. Can be replaced'''
        
        size = self.inFile.filesize()
        magic = self.inFile.read_string(4)
        key = self.inFile.read_string(8)
        
        while self.inFile.tell() != size:
            tag = self.inFile.read_string(4)
            print tag
            sectLen = self.inFile.read_long()
            if tag == "MATE":
                self.parse_materials(sectLen)
            elif tag == "TEXT":
                self.parse_textures(sectLen)
            elif tag == "MESH":
                self.parse_meshes(sectLen)
            elif tag == "FRAM":
                self.parse_frames(sectLen)
            else:
                self.inFile.seek(sectLen, 1)
            