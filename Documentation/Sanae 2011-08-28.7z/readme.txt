This version of Sanae adds support for blender import.
That means you can import any format supported by Sanae into Blender.

I currently have only written scrips for blender 2.49; 2.5x support
will come later.

For 2.49 users, it is located under file --> import --> .Sanae Importer.

To use Sanae 3D with blender, go into the Blender folder that came with this
archive and copy the SanaeImporter.py to the "scripts" folder in your
main Blender directory. Then copy the entire Sanae3D folder into the
scripts folder as well.

This program can still be called directly from the command-line as usual,
and that will not change.

I've changed the structure a little bit, but the main point of entry is the
Sanae.py file